import javax.swing.JOptionPane;
import java.io.*;
import java.util.Scanner;

class Arquivo{
	public static void main(String args[]) throws IOException{
		Scanner ler = new Scanner(System.in);
		int i, n;
	
		n = Integer.parseInt(JOptionPane.showInputDialog("Informe o número para a tabuada:\n"));
	
		FileWriter arq = new FileWriter("C:\\Users\\Aluno\\Documents\\java\\tabuada.txt");
		PrintWriter gravarArq = new PrintWriter(arq);
	
		gravarArq.printf("+--Resultado--+%n");
		for (i=1; i<=10; i++) {
			gravarArq.printf("| %2d X %d = %2d |%n", i, n, (i*n));
		}
		gravarArq.printf("+-------------+%n");
	
		arq.close();
	
		JOptionPane.showMessageDialog(null,"Tabuada do " + n  + " foi gravada com sucesso em \"d:\\tabuada.txt\".");	
	}
}